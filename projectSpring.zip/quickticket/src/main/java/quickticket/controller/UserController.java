package quickticket.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.annotation.SessionScope;

import quickticket.entity.Report;
import quickticket.entity.Seat;
import quickticket.entity.Selected;
import quickticket.entity.Show;
import quickticket.entity.User;
import quickticket.repository.SeatRepository;
import quickticket.repository.SelectedRepository;
import quickticket.repository.ShowRepository;

@Controller
@SessionScope
public class UserController 
{
	private final quickticket.repository.UserRepository UserRepository;
	
	private final quickticket.repository.SelectedRepository sr;
	
	private final quickticket.repository.SeatRepository ser;
	
	private final quickticket.repository.ShowRepository ser1;
	
	@Autowired
	public UserController(quickticket.repository.UserRepository userRepository, SelectedRepository sr,SeatRepository ser,ShowRepository ser1) 
	{
		this.UserRepository = userRepository;
		this.sr = sr;
		this.ser = ser;
		this.ser1 = ser1;
	}
	
	@GetMapping("signup")
	public String showSignUpForm() {
		return "signup";
	}
	
	@GetMapping("/p")
	public String showForm(@RequestParam("m") String m,Model m1)
	{
		//List<Selected> L = sr.findAll();
		
		m=m.substring(7);
		
		System.out.println(m);
		
		m1.addAttribute("moviename", m);
		
		return "pick";
	}
	
	@PostMapping("signup")
	public String submitSignUpForm(User user,Model model) 
	{
		if(user.getEmail()==null||user.getPassword()==null||user.getName()==null)
		{
			System.out.println("Cannot register");
		}
		model.addAttribute("a", "Successfully registered, please login now.");
		UserRepository.save(user);
		return "signup";
	}
	
	@GetMapping("book")
	public String showSeats(@RequestParam(name="uname")String name,Model model) 
	{
		ArrayList<Seat> s = (ArrayList<Seat>)ser.findAll();
		
		System.out.println(s);
		
		model.addAttribute("list", s);
		
		ArrayList<Show> s1 = (ArrayList<Show>)ser1.findAll();
		
		String time = null;
		for(Show e:s1)
		{
			 time = e.getShow_time();
		}
		
		model.addAttribute("time",time);
		
		model.addAttribute("uname",name);
		
		return "seats";
	}
	
	@GetMapping("user_login")
	public String showLoginexist() 
	{
		return "user_login";
	}
	
	@GetMapping("/")
	public String showWelcome(Model model) 
	{
		if(model.containsAttribute("loname")!=true);
		model.addAttribute("loname", "login please");
		return "index";
	}
	
	@GetMapping("admin")
	public String showAdmin() 
	{
		return "admin_login";
	}
	
	@GetMapping("continue")
	public String showTicketInfo(Selected se,Model model) 
	{
		System.out.println(se);
		/*
		 * String l[] = se.getSeats().split(",");
		 * 
		 * for(int i=0;i<l.length;i++) { Selected s = new
		 * Selected(se.getName(),se.getNos(),l[i]); sr.save(se); }
		 */
		
		sr.save(se);
		
		model.addAttribute("se",se);
		
		return "ticket_info";
	}
	
	@PostMapping("verify")
	public String loginPost(@RequestParam("username") String un,@RequestParam("pass") String pass,Model model) 
	{
		ArrayList<User> l=(ArrayList<User>) UserRepository.findAll();
		
		int c=0;
		
		for(User u:l)
		{
			System.out.println(u);
			if(u.getEmail().equals(un)&u.getPassword().equals(pass))
			{
				c=1;
				model.addAttribute("loname", "Hi,  "+u.getName().toLowerCase());
				break;
			}
		}
		
		if(c==1)
			return "index";
		else
		{	model.addAttribute("message", "Username or password incorrect.");
		
			return "user_login";
		}
	
	}
	
	@GetMapping("/ticket")
	  public String handleForexRequest(Model model) 
	{
		List<Selected>l = sr.findAll();
		
		Selected s = l.get(l.size()-1);
		
		System.out.println(s);
		
	      model.addAttribute("report", getReport(s));
	      model.addAttribute("S","See you");
	      model.addAttribute("moviename", s.getName());
	      
	      return "reportView";
	}

	  public Report getReport(Selected s) {
	      Report report = new Report();
	      report.setName("Ticket Details");
	      report.setContent("Movie name: "+s.getName()+" \nNo of seats: "+s.getNos()+"  \nSeats: "+s.getSeats()+"\nGenerated time:"+LocalDateTime.now());
	      //report.setDate(LocalDateTime.now());
	      return report;
	  }
		
}
