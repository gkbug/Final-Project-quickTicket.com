package quickticket.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="prices_table")
public class Price
{
	@Id
	private String price_id;
	private String category;
	private Long price;
	public String getPrice_id() {
		return price_id;
	}
	public void setPrice_id(String price_id) {
		this.price_id = price_id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Price [price_id=" + price_id + ", category=" + category + ", price=" + price + "]";
	}
	public Price(String price_id, String category, Long price) {
		super();
		this.price_id = price_id;
		this.category = category;
		this.price = price;
	}
	public Price() {
		super();
		// TODO Auto-generated constructor stub
	}
}
