package quickticket.entity;

import java.time.LocalDateTime;

public class Report
{
	  private String name;
	  private String content;
	  private LocalDateTime date;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public Report(String name, String content, LocalDateTime date) {
		super();
		this.name = name;
		this.content = content;
		this.date = date;
	}
	public Report() {
		super();
		// TODO Auto-generated constructor stub
	}
}