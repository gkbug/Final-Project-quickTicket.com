package quickticket.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seats_selected")
public class Selected
{
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	private String name;
	private String nos;
	private String seats;
	public Selected(String name2, String nos2, String string) 
	{
		this.name=name2;
		this.nos = nos2;
		this.seats = string;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNos() {
		return nos;
	}
	public void setNos(String nos) {
		this.nos = nos;
	}
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	@Override
	public String toString() {
		return "Selected [name=" + name + ", nos=" + nos + ", seats=" + seats + "]";
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Selected(Long id, String name, String nos, String seats) {
		super();
		Id = id;
		this.name = name;
		this.nos = nos;
		this.seats = seats;
	}
	public Selected() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
