package quickticket.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seats_table")
public class Seat
{
	@Id
	private String seat_Id;
	private String category;
	private String status;
	private String seat_col_id;
	
	public String getSeat_Id() {
		return seat_Id;
	}
	public void setSeat_Id(String seat_Id) {
		this.seat_Id = seat_Id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Seat [seat_Id=" + seat_Id + ", category=" + category + ", status=" + status + "]";
	}
	public Seat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Seat(String seat_Id, String category, String status) {
		super();
		this.seat_Id = seat_Id;
		this.category = category;
		this.status = status;
	}
	public String getSeat_col_id() {
		return seat_col_id;
	}
	public void setSeat_col_id(String seat_col_id) {
		this.seat_col_id = seat_col_id;
	}
	
	
}
