package quickticket.entity;

import quickticket.entity.User;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tickets_table")
public class Ticket
{
	@Id
	private String ticket_id;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
	private User user;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "movie_id")
	private Movie movie;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "show_id")
	private Show show;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seat_id")
	private Seat seat;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "price_id")
	private Price price;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
	public Seat getSeat() {
		return seat;
	}
	public void setSeat(Seat seat) {
		this.seat = seat;
	}
	public Price getPrice() {
		return price;
	}
	public void setPrice(Price price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Ticket [user=" + user + ", movie=" + movie + ", show=" + show + ", seat=" + seat + ", price=" + price
				+ "]";
	}
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
