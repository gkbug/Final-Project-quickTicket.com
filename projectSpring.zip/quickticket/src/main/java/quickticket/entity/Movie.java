package quickticket.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movies_table")
public class Movie
{
	private String movie_name;
	@Id
	private String movie_id;
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}
	public String getMovie_id() {
		return movie_id;
	}
	public void setMovie_id(String movie_id) {
		this.movie_id = movie_id;
	}
	@Override
	public String toString() {
		return "Movie [movie_name=" + movie_name + ", movie_id=" + movie_id + "]";
	}
	public Movie(String movie_name, String movie_id) {
		super();
		this.movie_name = movie_name;
		this.movie_id = movie_id;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
