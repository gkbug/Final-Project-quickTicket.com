package quickticket.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="shows_table")
public class Show
{
	@Id
	private String show_id;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "movie_id")
	private Movie movie;
	
	private String show_date;
	private String show_time;
	public String getShow_id() {
		return show_id;
	}
	public void setShow_id(String show_id) {
		this.show_id = show_id;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	public String getShow_date() {
		return show_date;
	}
	public void setShow_date(String show_date) {
		this.show_date = show_date;
	}
	public String getShow_time() {
		return show_time;
	}
	public void setShow_time(String show_time) {
		this.show_time = show_time;
	}
	@Override
	public String toString() {
		return "Show [show_id=" + show_id + ", movie=" + movie + ", show_date=" + show_date + ", show_time=" + show_time
				+ "]";
	}
	public Show(String show_id, Movie movie, String show_date, String show_time) {
		super();
		this.show_id = show_id;
		this.movie = movie;
		this.show_date = show_date;
		this.show_time = show_time;
	}
	public Show() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
