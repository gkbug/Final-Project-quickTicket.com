package quickticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import quickticket.entity.Selected;

@Repository
public interface SelectedRepository extends JpaRepository<Selected,Long>
{

}
