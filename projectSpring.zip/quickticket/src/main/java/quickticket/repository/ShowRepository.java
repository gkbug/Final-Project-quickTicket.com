package quickticket.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import quickticket.entity.Show;

@Repository
public interface ShowRepository  extends CrudRepository<Show, String>
{

}
